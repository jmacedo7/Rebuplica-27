import React from 'react';

export default function App() {
  return (
    <div className="grain min-h-screen flex items-center justify-center" data-testid="boot-screen">
      <p className="font-mono text-sm text-muted">Rebuplica 27 — inicializando…</p>
    </div>
  );
}
